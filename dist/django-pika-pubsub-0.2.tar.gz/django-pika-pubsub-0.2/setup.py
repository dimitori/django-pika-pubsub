from setuptools import setup

requires = [
    'pika>=1.1.0,<1.2.0'
]


setup(
    install_requires=requires
)
