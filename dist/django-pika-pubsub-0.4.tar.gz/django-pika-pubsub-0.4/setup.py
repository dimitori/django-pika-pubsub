from setuptools import setup

requires = [
    'pika>=1.1.0'
]


setup(
    install_requires=requires
)
