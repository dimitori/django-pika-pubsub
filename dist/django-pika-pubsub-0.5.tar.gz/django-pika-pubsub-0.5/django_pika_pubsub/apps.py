from django.apps import AppConfig


class DjangoPubsubConfig(AppConfig):
    name = 'django_pika_pubsub'
